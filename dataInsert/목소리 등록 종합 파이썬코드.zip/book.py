import requests

def __book_get(url, headers):
    return requests.get(f"{url}/book", headers=headers)

def book_info(url, access_token):
    headers = {'Authorization' : access_token}
    books = __book_get(url, headers).json()['data']

    book_list = []

    for book in books['bookResDtoList']:
        data = {
            "bookId" : book['bookId'],
            "title" : book['title'],
            "totalPageCnt" : book['totalPageCnt']
        }
        book_list.append(data)
    return book_list

def __page_get(url, headers, bookId):
    return requests.get(f"{url}/page/{bookId}", headers=headers)

def page_info(url, access_token, bookId):
    headers = {'Authorization' : access_token}
    pages = __page_get(url, headers, bookId).json()['data']
    size = pages['size']
    return size

def __content_get(url, headers, bookId, pageId):
    return requests.get(f"{url}/content/{bookId}/{pageId}", headers=headers)

def content_info(url, access_token, bookId, pageId):
    headers = {'Authorization' : access_token}
    contents = __content_get(url, headers, bookId, pageId).json()['data']
    content_list = []
    for content in contents:
        content_id = content['content_id']
        content_list.append(content_id)
    return content_list