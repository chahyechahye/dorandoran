import user
import book
import voice
import contentVoice
import os

url = "https://dorandoran.site/api"

def select_mode():
    print("[ 1 ] : 베이스 voice 등록")
    print("[ 2 ] : 학습된 목소리 등록")
    print(f"원하는 모드를 선택해주세요 : ", end="")
    key = input()
    if key == "1":
        raw_voice()
    elif key == "2":
        convert_voice()
    else:
        raise ValueError("잘못된 번호 입력")
def print_book_list(book_list):
    for book in book_list:
        print("[ %s ] %s / 페이지 수 : %s" % (book['bookId'], book['title'], book['totalPageCnt']))

def select_book(book_list):
    print_book_list(book_list)
    print("목소리를 입력할 책을 선택하세요 : ", end="")
    input_book_id = int(input())
    for book in book_list:
        if book['bookId'] == input_book_id:
            return book
    raise ValueError("잘못된 번호 입력")

def select_directory(path):
    directory_list = os.listdir(path)
    idx = 1
    for dir in directory_list:
        print("[ %s ] %s" % (idx, dir))
        idx += 1
    print("입력할 디렉토리 번호를 선택하세요 : ", end="")
    num = int(input())
    return directory_list[num-1]

def input_voice(path):
    try:
        input_directory = select_directory(path)
        directory = f"{path}/{input_directory}"
        file_list = os.listdir(directory)
        file_list.sort()
        edit_file_list = []
        for file in file_list:
            edit_file_list.append(f"{directory}/{file}")
        return(edit_file_list)
    except OSError as e:
        raise ValueError(f"Error reading directory {directory}: {e}")

def input_gender():
    print("1 : MALE\n2 : FEMALE")
    print("입력한 목소리의 성별을 입력해주세요 : ", end="")
    idx = int(input())
    if idx == 1:
        return "MALE"
    elif idx == 2:
        return "FEMALE"
    else:
        print("올바른 성별을 입력해주세요.")
        return input_gender()

def checkLength(list1, list2):
    list1_len = len(list1)
    list2_len = len(list2)
    if list1_len != list2_len:
        if list1_len > list2_len:
            print("녹음 파일 : %s개, 컨텐츠 : %s개" % (list1_len, list2_len))
            raise ValueError("녹음 파일이 컨텐츠 보다 많습니다.")
        elif list1_len < list2_len:
            print("녹음 파일 : %s개, 컨텐츠 : %s개" % (list1_len, list2_len))
            raise ValueError("녹음 파일이 컨텐츠 보다 적습니다.")

def raw_voice():
    try:
        access_token = user.login(url)
        book_list = book.book_info(url, access_token)
        selected_book = select_book(book_list)
        size = book.page_info(url, access_token, selected_book['bookId'])
        content_list = []
        for i in range(1, size+1):
            contents = book.content_info(url, access_token, selected_book['bookId'], i)
            for content in contents:
                content_list.append(content)
        file_list = input_voice("voice")
        gender = input_gender()
        checkLength(file_list, content_list)
        for i in range(0, len(content_list)):
            file_path = file_list[i]
            content_id = content_list[i]
            voice.upload_voice(url, access_token, content_id, gender, file_path)
        os.system("pause")
    except Exception as e:
        print(e)
        raw_voice()

def select_user_list(user_list):
    for user in user_list:
        print(f"[ {user['id']} ] : 이름 {user['name']}")
    print("학습된 음성을 넣을 유저를 선택해주세요 : ", end="")
    key = input()
    for user in user_list:
        if str(user['id']) == key:
            return user['id']

def select_redis_gender(user_id):
    print("======레디스에 생성될 성별=======")
    gender = input_gender()
    user.create_redis(url, user_id, gender)

def convert_voice():
    access_token = user.login(url)
    user_list = user.all_user(url, access_token)
    user_id = select_user_list(user_list)
    book_list = book.book_info(url, access_token)
    selected_book = select_book(book_list)
    size = book.page_info(url, access_token, selected_book['bookId'])
    content_list = []
    for i in range(1, size+1):
        contents = book.content_info(url, access_token, selected_book['bookId'], i)
        for content in contents:
            content_list.append(content)
    file_list = input_voice("convertVoice")
    gender = input_gender()
    checkLength(file_list, content_list)
    select_redis_gender(user_id)
    for i in range(0, len(content_list)):
        file_path = file_list[i]
        content_id = content_list[i]
        contentVoice.upload_content_voice(url, access_token, content_id, user_id, gender, file_path)
    os.system("pause")
    

def start():
    try:
        select_mode()
    except Exception as e:
        print(e)
        select_mode()

start()