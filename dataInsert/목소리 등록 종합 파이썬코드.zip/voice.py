import requests
from requests_toolbelt import MultipartEncoder

def __voice_post(url, headers, voice_data):
    return requests.post(f"{url}/admin_voice", headers=headers, data=voice_data)

def upload_voice(url, access_token, content_id, gender, file_path):
    print(gender)
    voice_data = {
        "contentId" : str(content_id),
        "gender" : gender,
        "file" : (file_path, open(file_path, 'rb'), 'audio/wav')
    }
    m = MultipartEncoder(fields=voice_data)
    headers = {'Content-Type' : m.content_type, 'Authorization' : access_token}
    response = __voice_post(url, headers, m)
    response.raise_for_status()
    if response.status_code == 200:
        print("목소리 등록 성공")