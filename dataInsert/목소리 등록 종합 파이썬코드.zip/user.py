import requests

def __select_login():
    print("로그인 방법 선택")
    print("1 : 자동 로그인")
    print("2 : 직접 로그인")
    key = input()
    if key == '1':
        return __auto_data()
    elif key == '2':
        return __manual_data()

def __post_login(url, login_data):
    return requests.post(f"{url}/user", json=login_data)

def __auto_data():
    data = {
        "name" : "어드민",
        "email" : "admin@test.com",
        "userRole" : "ADMIN"
    }
    return data

def __manual_data():
    print("이름 입력(어드민) : ", end="")
    name = input()
    print("이메일 입력(admin@test.com) : ", end="")
    email = input()
    print("userRole(ADMIN) : ", end="")
    userRole = input()
    data = {
        "name" : name,
        "email" : email,
        "userRole" : userRole
    }
    return data

def login(url):
    data = __select_login()
    response = __post_login(url, data)
    if response.status_code == 200:
        print("로그인 성공")
    return response.headers.get("AccessToken")

def __get_all_user(url, headers):
    return requests.get(f"{url}/user/admin", headers=headers).json()['data']


def all_user(url, access_token):
    headers = {'Authorization' : access_token}
    return __get_all_user(url, headers)

def __post_create_redis(url, data):
    return requests.post(f"{url}/voice/redis", json=data)

def create_redis(url, user_id, gender):
    data = {
        "userId" : str(user_id),
        "gender" : gender
    }
    response = __post_create_redis(url, data)
    response.raise_for_status()
    if response.status_code == 200:
        print("로그인 성공")