import requests
from requests_toolbelt import MultipartEncoder

def __content_voice_post(url, headers, voice_data):
    return requests.post(f"{url}/content/voice", headers=headers, data=voice_data)

def upload_content_voice(url, access_token, content_id, user_id, gender, file_path):
    voice_data = {
        "contentId" : str(content_id),
        "userId" : str(user_id),
        "gender" : gender,
        "file" : (file_path, open(file_path, 'rb'), 'audio/wav')
    }
    m = MultipartEncoder(fields=voice_data)
    headers = {'Content-Type' : m.content_type, 'Authorization' : access_token}
    response = __content_voice_post(url, headers, m)
    response.raise_for_status()
    if response.status_code == 200:
        print("목소리 등록 성공")